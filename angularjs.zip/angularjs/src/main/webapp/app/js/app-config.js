(function(){
    'use strict';

    angular.module('senai', []);
})();