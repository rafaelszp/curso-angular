package org.senai.angularjs.negocio.produto;

public class ProdutoDAO {

	protected Produto salvar(Produto entidade){
		return entidade;
	}
}
