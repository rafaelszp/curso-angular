package org.senai.angularjs.negocio.produto;


public class ProdutoController {

}
