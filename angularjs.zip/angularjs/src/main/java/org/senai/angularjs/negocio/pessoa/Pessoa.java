package org.senai.angularjs.negocio.pessoa;

public class Pessoa {

}
